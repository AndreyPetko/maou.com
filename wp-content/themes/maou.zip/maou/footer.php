<div id="footer">

	<div class="col-md-10 col-sm-6 footer-item">
		<!-- 	<h6>Заголовок</h6> -->
		
			<?php
				wp_nav_menu('menu=header_menu');
				?>

		</div>
		
	<!-- 	<div class="col-md-2 col-sm-6 footer-item">
			<h6>Заголовок</h6>
			<ul>
				<li>Подпункт</li>
				<li>Подпункт</li>
				<li>Подпункт</li>
				<li>Подпункт</li>
				<li>Подпункт</li>
				<li>Подпункт</li>
			</ul>
		</div> -->

	
		<div class="col-md-2 col-sm-6 footer-item footer-social">
		<!-- 	<h6>Следите за нами</h6> -->
			<ul>
				<li><a href="" target="_blank"><img src="/wp-content/themes/maou/images/icon-vk.png"></a></li>
				<li><a href="" target="_blank"><img src="/wp-content/themes/maou/images/icon-tw.png"></a></li>
				<li><a href="" target="_blank"><img src="/wp-content/themes/maou/images/icon-fb.png"></a></li>
				<li><a href="" target="_blank"><img src="/wp-content/themes/maou/images/icon-insta.png"></a></li>
				<li><a href="" target="_blank"><img src="/wp-content/themes/maou/images/icon-ok.png"></a></li>
				<li><a href="" target="_blank"><img src="/wp-content/themes/maou/images/icon-yout.png"></a></li>

			</ul>
		</div>
		<div class="clear"></div>
		<div class="footer-line"></div>
		<div class="footer-txt">
			<div><p>© МАОУ Селенгинская средняя общеобразовательная школа №1</p></div>
			<div><p>Создание сайта</p> <a href="http://anastasiya-petko.com.ua">AP-studio</a></div>
		</div>
	</div>