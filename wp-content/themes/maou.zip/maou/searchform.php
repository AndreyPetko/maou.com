<form role="search" method="get" id="searchform" class="searchform" action="/">
	<input placeholder="Поиск" name="s" type="text">
	<input type="submit" value="">
	
</form>