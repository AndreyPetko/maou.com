<?php get_header(); ?>
<div class="row">
    <div class="col-md-9">

        <div class="article">
            <div class="title">
                <p>404</p>

            </div>

            <div class="row">
          
                <div class="alert alert-error">Страница не найдена</div>
                <div class="article-button">
                                <a href="/">На главную
                                </a>
                            </div>
            </div>
        </div>



    </div>
    <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>